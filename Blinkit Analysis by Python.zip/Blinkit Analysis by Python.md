****DATA ANALYSIS PYTHON PROJECT- BLINKIT ANALYSIS****



#**IMPORT LIBRARYS**



```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
```

#**IMPORT SAMPLE DATA**


```python
df=pd.read_csv("C:/Users/BHAGYASHREE/Desktop/data/BlinkIT Grocery Data.csv")
```


```python
df.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Item Fat Content</th>
      <th>Item Identifier</th>
      <th>Item Type</th>
      <th>Outlet Establishment Year</th>
      <th>Outlet Identifier</th>
      <th>Outlet Location Type</th>
      <th>Outlet Size</th>
      <th>Outlet Type</th>
      <th>Item Visibility</th>
      <th>Item Weight</th>
      <th>Total Sales</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Regular</td>
      <td>FDX32</td>
      <td>Fruits and Vegetables</td>
      <td>2012</td>
      <td>OUT049</td>
      <td>Tier 1</td>
      <td>Medium</td>
      <td>Supermarket Type1</td>
      <td>0.100014</td>
      <td>15.10</td>
      <td>145.4786</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Low Fat</td>
      <td>NCB42</td>
      <td>Health and Hygiene</td>
      <td>2022</td>
      <td>OUT018</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type2</td>
      <td>0.008596</td>
      <td>11.80</td>
      <td>115.3492</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Regular</td>
      <td>FDR28</td>
      <td>Frozen Foods</td>
      <td>2010</td>
      <td>OUT046</td>
      <td>Tier 1</td>
      <td>Small</td>
      <td>Supermarket Type1</td>
      <td>0.025896</td>
      <td>13.85</td>
      <td>165.0210</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Regular</td>
      <td>FDL50</td>
      <td>Canned</td>
      <td>2000</td>
      <td>OUT013</td>
      <td>Tier 3</td>
      <td>High</td>
      <td>Supermarket Type1</td>
      <td>0.042278</td>
      <td>12.15</td>
      <td>126.5046</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Low Fat</td>
      <td>DRI25</td>
      <td>Soft Drinks</td>
      <td>2015</td>
      <td>OUT045</td>
      <td>Tier 2</td>
      <td>Small</td>
      <td>Supermarket Type1</td>
      <td>0.033970</td>
      <td>19.60</td>
      <td>55.1614</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>low fat</td>
      <td>FDS52</td>
      <td>Frozen Foods</td>
      <td>2020</td>
      <td>OUT017</td>
      <td>Tier 2</td>
      <td>Small</td>
      <td>Supermarket Type1</td>
      <td>0.005505</td>
      <td>8.89</td>
      <td>102.4016</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Low Fat</td>
      <td>NCU05</td>
      <td>Health and Hygiene</td>
      <td>2011</td>
      <td>OUT010</td>
      <td>Tier 3</td>
      <td>Small</td>
      <td>Grocery Store</td>
      <td>0.098312</td>
      <td>11.80</td>
      <td>81.4618</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Low Fat</td>
      <td>NCD30</td>
      <td>Household</td>
      <td>2015</td>
      <td>OUT045</td>
      <td>Tier 2</td>
      <td>Small</td>
      <td>Supermarket Type1</td>
      <td>0.026904</td>
      <td>19.70</td>
      <td>96.0726</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Low Fat</td>
      <td>FDW20</td>
      <td>Fruits and Vegetables</td>
      <td>2000</td>
      <td>OUT013</td>
      <td>Tier 3</td>
      <td>High</td>
      <td>Supermarket Type1</td>
      <td>0.024129</td>
      <td>20.75</td>
      <td>124.1730</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Low Fat</td>
      <td>FDX25</td>
      <td>Canned</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.101562</td>
      <td>NaN</td>
      <td>181.9292</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>LF</td>
      <td>FDX21</td>
      <td>Snack Foods</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.084555</td>
      <td>NaN</td>
      <td>109.8912</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Low Fat</td>
      <td>NCU41</td>
      <td>Health and Hygiene</td>
      <td>2017</td>
      <td>OUT035</td>
      <td>Tier 2</td>
      <td>Small</td>
      <td>Supermarket Type1</td>
      <td>0.052045</td>
      <td>18.85</td>
      <td>192.1846</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Low Fat</td>
      <td>FDL20</td>
      <td>Fruits and Vegetables</td>
      <td>2022</td>
      <td>OUT018</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type2</td>
      <td>0.128938</td>
      <td>17.10</td>
      <td>112.3886</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Low Fat</td>
      <td>NCR54</td>
      <td>Household</td>
      <td>2000</td>
      <td>OUT013</td>
      <td>Tier 3</td>
      <td>High</td>
      <td>Supermarket Type1</td>
      <td>0.090487</td>
      <td>16.35</td>
      <td>195.2110</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Low Fat</td>
      <td>FDH19</td>
      <td>Meat</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.032928</td>
      <td>NaN</td>
      <td>173.1738</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Regular</td>
      <td>FDB57</td>
      <td>Fruits and Vegetables</td>
      <td>2017</td>
      <td>OUT035</td>
      <td>Tier 2</td>
      <td>Small</td>
      <td>Supermarket Type1</td>
      <td>0.018802</td>
      <td>20.25</td>
      <td>222.1772</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Low Fat</td>
      <td>FDO23</td>
      <td>Breads</td>
      <td>2022</td>
      <td>OUT018</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type2</td>
      <td>0.147024</td>
      <td>17.85</td>
      <td>93.7436</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Low Fat</td>
      <td>NCB07</td>
      <td>Household</td>
      <td>2012</td>
      <td>OUT049</td>
      <td>Tier 1</td>
      <td>Medium</td>
      <td>Supermarket Type1</td>
      <td>0.077628</td>
      <td>19.20</td>
      <td>197.6110</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>18</th>
      <td>Low Fat</td>
      <td>FDJ56</td>
      <td>Fruits and Vegetables</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.182515</td>
      <td>NaN</td>
      <td>98.7700</td>
      <td>5.0</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Low Fat</td>
      <td>DRN47</td>
      <td>Hard Drinks</td>
      <td>2022</td>
      <td>OUT018</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type2</td>
      <td>0.016895</td>
      <td>12.10</td>
      <td>178.5660</td>
      <td>5.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.tail(10)

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Item Fat Content</th>
      <th>Item Identifier</th>
      <th>Item Type</th>
      <th>Outlet Establishment Year</th>
      <th>Outlet Identifier</th>
      <th>Outlet Location Type</th>
      <th>Outlet Size</th>
      <th>Outlet Type</th>
      <th>Item Visibility</th>
      <th>Item Weight</th>
      <th>Total Sales</th>
      <th>Rating</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>8513</th>
      <td>Regular</td>
      <td>DRY23</td>
      <td>Soft Drinks</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.108568</td>
      <td>NaN</td>
      <td>42.9112</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>8514</th>
      <td>low fat</td>
      <td>FDA11</td>
      <td>Baking Goods</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.043029</td>
      <td>NaN</td>
      <td>94.7436</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>8515</th>
      <td>low fat</td>
      <td>FDK38</td>
      <td>Canned</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.053032</td>
      <td>NaN</td>
      <td>149.1734</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>8516</th>
      <td>low fat</td>
      <td>FDO38</td>
      <td>Canned</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.072486</td>
      <td>NaN</td>
      <td>78.9986</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>8517</th>
      <td>low fat</td>
      <td>FDG32</td>
      <td>Fruits and Vegetables</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.175143</td>
      <td>NaN</td>
      <td>222.3772</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>8518</th>
      <td>low fat</td>
      <td>NCT53</td>
      <td>Health and Hygiene</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>164.5526</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>8519</th>
      <td>low fat</td>
      <td>FDN09</td>
      <td>Snack Foods</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.034706</td>
      <td>NaN</td>
      <td>241.6828</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>8520</th>
      <td>low fat</td>
      <td>DRE13</td>
      <td>Soft Drinks</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.027571</td>
      <td>NaN</td>
      <td>86.6198</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>8521</th>
      <td>reg</td>
      <td>FDT50</td>
      <td>Dairy</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.107715</td>
      <td>NaN</td>
      <td>97.8752</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>8522</th>
      <td>reg</td>
      <td>FDM58</td>
      <td>Snack Foods</td>
      <td>1998</td>
      <td>OUT027</td>
      <td>Tier 3</td>
      <td>Medium</td>
      <td>Supermarket Type3</td>
      <td>0.000000</td>
      <td>NaN</td>
      <td>112.2544</td>
      <td>4.0</td>
    </tr>
  </tbody>
</table>
</div>



#**SIZE OF DATA**


```python
print("Size of Data : ", df.shape)
```

    Size of Data :  (8523, 12)
    

#**FIELD INFO**


```python
df.columns
```




    Index(['Item Fat Content', 'Item Identifier', 'Item Type',
           'Outlet Establishment Year', 'Outlet Identifier',
           'Outlet Location Type', 'Outlet Size', 'Outlet Type', 'Item Visibility',
           'Item Weight', 'Total Sales', 'Rating'],
          dtype='object')



#**DATA TYPE**


```python
df.dtypes
```




    Item Fat Content              object
    Item Identifier               object
    Item Type                     object
    Outlet Establishment Year      int64
    Outlet Identifier             object
    Outlet Location Type          object
    Outlet Size                   object
    Outlet Type                   object
    Item Visibility              float64
    Item Weight                  float64
    Total Sales                  float64
    Rating                       float64
    dtype: object



#**DATA CLEANING**


```python

```


```python
print(df['Item Fat Content'].unique())
```

    ['Regular' 'Low Fat' 'low fat' 'LF' 'reg']
    


```python

```


```python
df['Item Fat Content']= df['Item Fat Content'].replace({'LF':'Low Fat','low fat':'Low Fat','reg': 'Regular'})
```


```python
print(df['Item Fat Content'].unique())
```

    ['Regular' 'Low Fat']
    

#**BUSINESS REQUIREMENTS**

#**KPI's REQUIREMENTS**


```python
#Total Sales
total_sales = df['Total Sales'].sum()

#Avg Sales
avg_sales = df['Total Sales'].mean()

#No of Item Sold
no_of_item_sold = df['Total Sales'].count()

#Avg Ratings
avg_ratings = df['Rating'].mean()

#Display

print(f"Total Sales: ${total_sales:,.0f}")
print(f"Averag Sales: ${avg_sales:,.0f}")
print(f"No of Items Sold: {no_of_item_sold:,.0f}")
print(f"Average Ratings: {avg_ratings:,.1f}")





```

    Total Sales: $1,201,681
    Averag Sales: $141
    No of Items Sold: 8,523
    Average Ratings: 4.0
    

#**CHARTS REQUIREMENTS**

**Total sales by Fat Content**


```python
sales_by_fat = df.groupby('Item Fat Content')['Total Sales'].sum()

plt.pie(sales_by_fat, labels = sales_by_fat.index,
        autopct= '%.1f%%',
        startangle= 90)


plt.title('Sales by Fat Content')
plt.axis('equal')
plt.show()
```


    
![png](output_24_0.png)
    


**Total sales by Item Type**


```python
Sales_by_type = df.groupby('Item Type')['Total Sales'].sum().sort_values(ascending=False)

plt.figure(figsize=(10,6))
bars = plt.bar(Sales_by_type.index, Sales_by_type.values)

plt.xticks(rotation=-90)
plt.xlabel('Item Type')
plt.ylabel('Total Sales')
plt.title('Total Sales by Item Type')

for bar in bars:
    plt.text(bar.get_x() + bar.get_width() / 2, bar.get_height(),
             f'{bar.get_height():,.0f}',ha='center', va='bottom', fontsize=8)
    
plt.tight_layout()
plt.show()
```


    
![png](output_26_0.png)
    


**Fat Content by Outlet for Total Sales**


```python
grouped = df.groupby(['Outlet Location Type','Item Fat Content'])['Total Sales'].sum().unstack()
grouped=grouped[['Regular','Low Fat']]

ax= grouped.plot(kind='bar', figsize=(8,5), title='Outlet Tier by Item Fat Content')
plt.xlabel('Outlet Location Type')
plt.ylabel('Total Sales')
plt.legend(title='Item Fat Content')
plt.tight_layout()
plt.show()
```


    
![png](output_28_0.png)
    


**Total Sales by Outlet Establishment**


```python
sales_by_year= df.groupby('Outlet Establishment Year')['Total Sales'].sum().sort_index()

plt.figure(figsize=(9,5))
plt.plot(sales_by_year.index, sales_by_year.values, marker='o', linestyle='-')

plt.xlabel('Outlet Establishment Year')
plt.ylabel('Total Sales')
plt.title('Outlet Establishment')

for x,y in zip(sales_by_year.index, sales_by_year.values):
    plt.text(x, y, f'{y:,.0f}', ha='center', va='bottom', fontsize=8)

plt.tight_layout()
plt.show()
```


    
![png](output_30_0.png)
    



```python
sales_by_size = df.groupby('Outlet Size')['Total Sales'].sum()

plt.figure(figsize=(4,4))
plt.pie(sales_by_size,labels=sales_by_size.index, autopct='%1.1f%%', startangle=90)
plt.title('Outlet Size')
plt.tight_layout()
plt.show()

```


    
![png](output_31_0.png)
    


**Sales by Outlet Location**


```python
sales_by_location = df.groupby('Outlet Location Type') ['Total Sales'].sum().reset_index()
sales_by_location = sales_by_location.sort_values('Total Sales', ascending=False)

plt.figure(figsize=(8,3)) #Smaller height , enough width
ax = sns.barplot(x='Total Sales',y='Outlet Location Type', data=sales_by_location)

plt.title('Total Sales by Outlet Location Type')
plt.xlabel('Total Sales')
plt.ylabel('Outlet Location Type')

plt.tight_layout()  #Ensure Layout fits without scroll
plt.show()
```


    
![png](output_33_0.png)
    



```python

```
