# BlinkIT Grocery Data Analysis — EDA, Cleaning & Baseline Model

This document contains Python code for loading, cleaning, exploring, and building a simple baseline model for the BlinkIT Grocery dataset.

How to use
- Save this file as `blinkit_analysis.md`.
- Open a Jupyter notebook or a `.py` file and copy the code blocks into cells / script.
- Update `DATA_PATH` to point to your CSV file: `C:/Users/PRIYADHARSHAN/Desktop/data/BlinkIT Grocery Data.csv` (default).
- Install required packages if not already: `pip install pandas numpy seaborn matplotlib scikit-learn`

---

## Requirements

```bash
pip install pandas numpy seaborn matplotlib scikit-learn
# optional: pip install jupyterlab notebook
```

(Include all the Python code blocks and explanations from your draft here.)
